#include <iostream>
#include <string>
using namespace std;

int main() {
    string s1 = "Hello", s2 = "World";
    cout << "Concatenated: " << s1 + s2;
    return 0;
}
